<template>
    <div>
        <v-row>
            <v-col v-for="tipo in tipos" :key="tipo.id">
                <v-card>
                    <v-img :src="tipo.fotos" alt="Imagen del tipo"></v-img>
                    <v-card-title>{{ tipo.tipo }}</v-card-title>
                </v-card>
            </v-col>
        </v-row>
    </div>
</template>
  
<script>
import { getProductos } from './../services/connectionManager';
import { getTipos } from './../services/connectionManager';


export default {
    data() {
        return {
            tipos: [],
            productos: [],
        };
    },
    methods: {
        getTotal() {
            getProductos().then((response) => {
                this.productos = response;
                console.log(response);
            }).catch((error) => {
                console.error("Error al obtener productos: ", error);
            });

            getTipos().then((response) => {
                this.tipos = response;
                console.log(response);
            }).catch((error) => {
                console.error("Error al obtener productos: ", error);
            });
        },

    },
    created() {
        this.getTotal();
    },
};
</script>
